#ifndef _COMHEADERS_HPP
#define _COMHEADERS_HPP

#include <fstream>
#include <iostream>
#include <map>
#include <vector>
#include <cstdlib>
#include <string>

using namespace std;

#endif
